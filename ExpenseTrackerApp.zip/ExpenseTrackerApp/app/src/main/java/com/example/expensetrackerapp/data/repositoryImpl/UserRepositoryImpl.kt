package com.example.expensetrackerapp.data.repositoryImpl

import com.example.expensetrackerapp.data.dao.UserDao
import com.example.expensetrackerapp.data.entities.User
import com.example.expensetrackerapp.data.repository.UserRepository

class UserRepositoryImpl(
    private val userDao: UserDao
) : UserRepository {

    override suspend fun upsertUser(user: User) {
        userDao.upsertUser(user)
    }

    override suspend fun deleteUser(user: User): Int {
        return userDao.deleteUser(user)
    }
}
