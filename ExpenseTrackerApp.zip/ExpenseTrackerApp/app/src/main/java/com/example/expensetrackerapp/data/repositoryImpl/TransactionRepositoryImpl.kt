package com.example.expensetrackerapp.data.repository

import com.example.expensetrackerapp.data.dao.CategorySummary
import com.example.expensetrackerapp.data.dao.MonthlySummary
import com.example.expensetrackerapp.data.dao.MonthlyTopCategoryExpense
import com.example.expensetrackerapp.data.dao.TopCategoryExpense
import com.example.expensetrackerapp.data.dao.TransactionDao
import com.example.expensetrackerapp.data.entities.Transaction
import kotlinx.coroutines.flow.Flow

class TransactionRepositoryImpl(
    private val transactionDao: TransactionDao
) : TransactionRepository {

    override suspend fun insertTransaction(transaction: Transaction) {
        transactionDao.insertTransaction(transaction)
    }

    override suspend fun upsertTransaction(transaction: Transaction) {
        transactionDao.upsertTransaction(transaction)
    }

    override suspend fun deleteTransaction(transaction: Transaction) {
        transactionDao.deleteTransaction(transaction)
    }

    override fun getAllTransactions(): Flow<List<Transaction>> {
        return transactionDao.getAllTransactions()
    }

    override fun getTransactionById(id: Int): Flow<Transaction?> {
        return transactionDao.getTransactionById(id)
    }

    override fun getTotalIncome(): Flow<Double> {
        return transactionDao.getTotalIncome()
    }

    override fun getTotalExpense(): Flow<Double> {
        return transactionDao.getTotalExpense()
    }

    override fun getTop3ExpenseCategories(): Flow<List<TopCategoryExpense>> {
        return transactionDao.getTop3ExpenseCategories()
    }

    override fun getMonthlyExpenses(): Flow<List<MonthlySummary>> {
        return transactionDao.getMonthlyExpenses()
    }

    override fun getMonthlyIncome(): Flow<List<MonthlySummary>> {
        return transactionDao.getMonthlyIncome()
    }

    override fun getExpensesByCategory(): Flow<List<CategorySummary>> {
        return transactionDao.getExpensesByCategory()
    }

    override fun getTop3ExpenseCategoriesByMonth(): Flow<List<MonthlyTopCategoryExpense>> {
        return transactionDao.getTop3ExpenseCategoriesByMonth()
    }
}
