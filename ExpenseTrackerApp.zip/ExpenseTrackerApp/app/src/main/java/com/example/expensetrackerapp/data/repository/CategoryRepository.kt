package com.example.expensetrackerapp.data.repository

import com.example.expensetrackerapp.data.entities.Category
import kotlinx.coroutines.flow.Flow

interface CategoryRepository {

    suspend fun insertCategory(category: Category)

    suspend fun updateCategory(category: Category)

    suspend fun deleteCategory(category: Category)

    fun getAllCategories(): Flow<List<Category>>

    fun getCategoryById(id: Int): Flow<Category?>

}

