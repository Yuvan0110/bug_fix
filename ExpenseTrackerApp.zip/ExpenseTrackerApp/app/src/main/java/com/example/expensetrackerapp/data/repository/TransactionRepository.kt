package com.example.expensetrackerapp.data.repository

import com.example.expensetrackerapp.data.dao.CategorySummary
import com.example.expensetrackerapp.data.dao.MonthlySummary
import com.example.expensetrackerapp.data.dao.MonthlyTopCategoryExpense
import com.example.expensetrackerapp.data.dao.TopCategoryExpense
import com.example.expensetrackerapp.data.entities.Transaction
import kotlinx.coroutines.flow.Flow

interface TransactionRepository {

    suspend fun insertTransaction(transaction: Transaction)

    suspend fun upsertTransaction(transaction: Transaction)

    suspend fun deleteTransaction(transaction: Transaction)

    fun getAllTransactions(): Flow<List<Transaction>>

    fun getTransactionById(id: Int): Flow<Transaction?>

    fun getTotalIncome(): Flow<Double>

    fun getTotalExpense(): Flow<Double>

    fun getTop3ExpenseCategories(): Flow<List<TopCategoryExpense>>

    fun getMonthlyExpenses(): Flow<List<MonthlySummary>>

    fun getMonthlyIncome(): Flow<List<MonthlySummary>>

    fun getExpensesByCategory(): Flow<List<CategorySummary>>

    fun getTop3ExpenseCategoriesByMonth(): Flow<List<MonthlyTopCategoryExpense>>
}
