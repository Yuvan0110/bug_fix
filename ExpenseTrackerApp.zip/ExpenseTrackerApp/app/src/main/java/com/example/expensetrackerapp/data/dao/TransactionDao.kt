package com.example.expensetrackerapp.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Upsert
import com.example.expensetrackerapp.data.entities.Transaction
import kotlinx.coroutines.flow.Flow

data class TopCategoryExpense(
    val categoryName: String,
    val totalExpense: Double
)

data class MonthlySummary(
    val month: String,
    val totalAmount: Double
)

data class CategorySummary(
    val categoryId: Int,
    val categoryName: String,
    val totalAmount: Double
)

data class MonthlyTopCategoryExpense(
    val month: String,
    val categoryName: String,
    val totalExpense: Double
)
@Dao
interface TransactionDao {

    @Insert
    suspend fun insertTransaction(transaction: Transaction)

    @Upsert
    suspend fun upsertTransaction(transaction: Transaction)

    @Delete
    suspend fun deleteTransaction(transaction: Transaction)

    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<Transaction>>

    @Query("SELECT * FROM transactions WHERE transactionId = :id")
    fun getTransactionById(id: Int): Flow<Transaction?>

    @Query("SELECT IFNULL(SUM(amount), 0) FROM transactions WHERE type = 'Income'")
    fun getTotalIncome(): Flow<Double>

    @Query("SELECT IFNULL(SUM(amount), 0) FROM transactions WHERE type = 'Expense'")
    fun getTotalExpense(): Flow<Double>

    @Query("""
        SELECT c.name AS categoryName, SUM(t.amount) AS totalExpense
        FROM transactions t
        INNER JOIN category c ON t.categoryId = c.categoryId
        WHERE t.type = 'Expense'
        GROUP BY c.categoryId, c.name
        ORDER BY totalExpense DESC
        LIMIT 3
    """)
    fun getTop3ExpenseCategories(): Flow<List<TopCategoryExpense>>

    @Query("""
        SELECT substr(timestamp, 4, 3) AS month,
               SUM(amount) AS totalAmount
        FROM transactions
        WHERE type = 'Expense'
        GROUP BY month
        ORDER BY month ASC
    """)
    fun getMonthlyExpenses(): Flow<List<MonthlySummary>>

    @Query("""
        SELECT strftime('%Y-%m', timestamp) AS month, SUM(amount) AS totalAmount
        FROM transactions
        WHERE type = 'Income'
        GROUP BY month
        ORDER BY month ASC
    """)
    fun getMonthlyIncome(): Flow<List<MonthlySummary>>

    @Query("""
        SELECT c.categoryId, c.name AS categoryName, IFNULL(SUM(t.amount), 0) AS totalAmount
        FROM transactions t
        JOIN category c 
        ON t.categoryId = c.categoryId
        WHERE t.type = 'Expense'
        GROUP BY c.categoryId, c.name
        ORDER BY totalAmount DESC
    """)
    fun getExpensesByCategory(): Flow<List<CategorySummary>>

    @Query("""
        SELECT month, categoryName, totalExpense FROM (
            SELECT 
                substr(t.timestamp, 4, 3) AS month,
                c.name AS categoryName,
                SUM(t.amount) AS totalExpense,
                ROW_NUMBER() OVER (PARTITION BY substr(t.timestamp, 4, 3) ORDER BY SUM(t.amount) DESC) AS rank
            FROM transactions t
            JOIN category c ON t.categoryId = c.categoryId
            WHERE t.type = 'Expense'
            GROUP BY c.categoryId
        )
        WHERE rank <= 3
        ORDER BY month ASC, totalExpense DESC
    """)
    fun getTop3ExpenseCategoriesByMonth(): Flow<List<MonthlyTopCategoryExpense>>
}
