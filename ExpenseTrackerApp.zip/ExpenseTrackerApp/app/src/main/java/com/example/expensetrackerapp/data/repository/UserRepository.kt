package com.example.expensetrackerapp.data.repository

import com.example.expensetrackerapp.data.entities.User

interface UserRepository {

    suspend fun upsertUser(user: User)
    suspend fun deleteUser(user: User): Int

}
