package com.example.expensetracker

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class ExpenseTrackerApp : Application() {
    // You can add onCreate() or other Application lifecycle callbacks here if needed
}
