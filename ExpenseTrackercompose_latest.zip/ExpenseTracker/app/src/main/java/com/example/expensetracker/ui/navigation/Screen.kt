package com.example.expensetracker.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.List
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(
    val route: String,
    val label: String,
    val icon: ImageVector
) {
    object AddExpense : Screen(
        route = "add_expense_screen",
        label = "Add",
        icon = Icons.Filled.AddCircle
    )
    object TransactionHistory : Screen(
        route = "transaction_history_screen",
        label = "History",
        icon = Icons.Filled.List
    )
    object SpendingPatterns : Screen(
        route = "spending_patterns_screen",
        label = "Analytics",
        icon = Icons.Filled.Analytics
    )
}

val bottomNavItems = listOf(
    Screen.AddExpense,
    Screen.TransactionHistory,
    Screen.SpendingPatterns
)
