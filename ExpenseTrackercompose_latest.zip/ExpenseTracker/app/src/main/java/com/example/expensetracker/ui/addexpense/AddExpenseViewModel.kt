package com.example.expensetracker.ui.addexpense

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.expensetracker.data.model.Category
import com.example.expensetracker.data.model.Transaction
import com.example.expensetracker.data.repository.ExpenseRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class AddExpenseUiState(
    val amount: String = "",
    val description: String = "",
    val date: Long = System.currentTimeMillis(),
    val selectedCategoryId: Long? = null,
    val categories: List<Category> = emptyList(), // This will be populated from LiveData
    val isSaving: Boolean = false,
    val errorMessage: String? = null,
    val transactionType: String = "Expense" // "Expense" or "Income"
)

@HiltViewModel
class AddExpenseViewModel @Inject constructor(
    private val expenseRepository: ExpenseRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(AddExpenseUiState())
    val uiState: StateFlow<AddExpenseUiState> = _uiState.asStateFlow()

    val categories: LiveData<List<Category>> = expenseRepository.getAllCategories()

    fun onAmountChange(amount: String) {
        _uiState.value = _uiState.value.copy(amount = amount)
    }

    fun onDescriptionChange(description: String) {
        _uiState.value = _uiState.value.copy(description = description)
    }

    fun onDateChange(date: Long) {
        _uiState.value = _uiState.value.copy(date = date)
    }

    fun onCategoryChange(categoryId: Long) {
        _uiState.value = _uiState.value.copy(selectedCategoryId = categoryId)
    }

    fun onTransactionTypeChange(type: String) {
        _uiState.value = _uiState.value.copy(transactionType = type)
    }

    fun saveTransaction() {
        val currentState = _uiState.value
        if (currentState.selectedCategoryId == null) {
            _uiState.value = currentState.copy(errorMessage = "Please select a category.")
            return
        }
        if (currentState.amount.isBlank() || currentState.amount.toDoubleOrNull() == null || currentState.amount.toDoubleOrNull()!! <= 0) {
            _uiState.value = currentState.copy(errorMessage = "Please enter a valid amount.")
            return
        }

        _uiState.value = currentState.copy(isSaving = true, errorMessage = null)

        viewModelScope.launch {
            try {
                val categoryName = categories.value?.find { it.id == currentState.selectedCategoryId }?.name ?: "N/A"
                val transaction = Transaction(
                    amount = currentState.amount.toDouble(),
                    date = currentState.date,
                    description = currentState.description.ifBlank { categoryName },
                    categoryId = currentState.selectedCategoryId,
                    type = currentState.transactionType
                )
                expenseRepository.insertTransaction(transaction)
                // Reset state or navigate away after successful save
                 _uiState.value = AddExpenseUiState(categories = categories.value ?: emptyList()) // Reset form, preserve categories
            } catch (e: Exception) {
                _uiState.value = currentState.copy(isSaving = false, errorMessage = "Failed to save transaction: ${e.message}")
            }
        }
    }
     // Helper to update categories in UiState when LiveData changes
    fun updateCategoriesInUiState(newCategories: List<Category>) {
        _uiState.value = _uiState.value.copy(
            categories = newCategories,
            // Optionally, set a default selected category if none is selected
            // selectedCategoryId = _uiState.value.selectedCategoryId ?: newCategories.firstOrNull()?.id
        )
    }
}
