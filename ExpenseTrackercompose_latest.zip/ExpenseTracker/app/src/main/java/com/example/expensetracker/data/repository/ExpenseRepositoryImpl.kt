package com.example.expensetracker.data.repository

import androidx.lifecycle.LiveData
import com.example.expensetracker.data.local.CategoryDao
import com.example.expensetracker.data.local.TransactionDao
import com.example.expensetracker.data.model.Category
import com.example.expensetracker.data.model.Transaction
import kotlinx.coroutines.flow.Flow

class ExpenseRepositoryImpl(
    private val transactionDao: TransactionDao,
    private val categoryDao: CategoryDao
) : ExpenseRepository {

    // Transaction operations
    override fun getAllTransactions(): Flow<List<Transaction>> {
        return transactionDao.getAllTransactions()
    }

    override fun getTransactionById(transactionId: Long): LiveData<Transaction?> {
        return transactionDao.getTransactionById(transactionId)
    }

    override suspend fun insertTransaction(transaction: Transaction): Long {
        return transactionDao.insertTransaction(transaction)
    }

    override suspend fun updateTransaction(transaction: Transaction) {
        transactionDao.updateTransaction(transaction)
    }

    override suspend fun deleteTransaction(transaction: Transaction) {
        transactionDao.deleteTransaction(transaction)
    }

    override fun getTransactionsByCategoryId(categoryId: Long): LiveData<List<Transaction>> {
        return transactionDao.getTransactionsByCategoryId(categoryId)
    }

    // Category operations
    override fun getAllCategories(): LiveData<List<Category>> {
        return categoryDao.getAllCategories()
    }

    override fun getCategoryById(categoryId: Long): LiveData<Category?> {
        return categoryDao.getCategoryById(categoryId)
    }

    override suspend fun insertCategory(category: Category): Long {
        return categoryDao.insertCategory(category)
    }

    override suspend fun insertCategories(categories: List<Category>) {
        categoryDao.insertCategories(categories)
    }

    override suspend fun getCategoryByName(name: String): Category? {
        return categoryDao.getCategoryByName(name)
    }

    override suspend fun updateCategory(category: Category) {
        categoryDao.updateCategory(category)
    }

    override suspend fun deleteCategory(category: Category) {
        categoryDao.deleteCategory(category)
    }
}
