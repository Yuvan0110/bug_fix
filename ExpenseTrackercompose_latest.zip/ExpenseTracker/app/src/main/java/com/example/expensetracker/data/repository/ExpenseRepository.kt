package com.example.expensetracker.data.repository

import androidx.lifecycle.LiveData
import com.example.expensetracker.data.model.Category
import com.example.expensetracker.data.model.Transaction
import kotlinx.coroutines.flow.Flow

interface ExpenseRepository {

    // Transaction operations
    fun getAllTransactions(): Flow<List<Transaction>>
    fun getTransactionById(transactionId: Long): LiveData<Transaction?>
    suspend fun insertTransaction(transaction: Transaction): Long
    suspend fun updateTransaction(transaction: Transaction)
    suspend fun deleteTransaction(transaction: Transaction)
    fun getTransactionsByCategoryId(categoryId: Long): LiveData<List<Transaction>>

    // Category operations
    fun getAllCategories(): LiveData<List<Category>>
    fun getCategoryById(categoryId: Long): LiveData<Category?>
    suspend fun insertCategory(category: Category): Long
    suspend fun insertCategories(categories: List<Category>)
    suspend fun getCategoryByName(name: String): Category?
    suspend fun updateCategory(category: Category)
    suspend fun deleteCategory(category: Category)
}
