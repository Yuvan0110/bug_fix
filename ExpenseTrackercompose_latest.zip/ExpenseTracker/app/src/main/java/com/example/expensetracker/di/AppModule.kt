package com.example.expensetracker.di

import android.content.Context
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.expensetracker.data.local.AppDatabase
import com.example.expensetracker.data.local.CategoryDao
import com.example.expensetracker.data.local.TransactionDao
import com.example.expensetracker.data.model.Category
import com.example.expensetracker.data.model.Transaction
import com.example.expensetracker.data.repository.ExpenseRepository
import com.example.expensetracker.data.repository.ExpenseRepositoryImpl
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.Date
import javax.inject.Provider
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideAppDatabase(
        @ApplicationContext appContext: Context,
        categoryDaoProvider: Provider<CategoryDao>,
        transactionDaoProvider: Provider<TransactionDao> // Added TransactionDao provider
    ): AppDatabase {
        return Room.databaseBuilder(
            appContext,
            AppDatabase::class.java,
            "expense_tracker_database"
        )
        .fallbackToDestructiveMigration(true) // Updated
        .addCallback(AppDatabaseCallback(categoryDaoProvider, transactionDaoProvider)) // Pass both providers
        .build()
    }

    @Provides
    @Singleton
    fun provideTransactionDao(appDatabase: AppDatabase): TransactionDao {
        return appDatabase.transactionDao()
    }

    @Provides
    @Singleton
    fun provideCategoryDao(appDatabase: AppDatabase): CategoryDao {
        return appDatabase.categoryDao()
    }

    @Provides
    @Singleton
    fun provideExpenseRepository(
        transactionDao: TransactionDao,
        categoryDao: CategoryDao
    ): ExpenseRepository {
        return ExpenseRepositoryImpl(transactionDao, categoryDao)
    }

    private class AppDatabaseCallback(
        private val categoryDaoProvider: Provider<CategoryDao>,
        private val transactionDaoProvider: Provider<TransactionDao> // Added TransactionDao provider
    ) : RoomDatabase.Callback() {
        private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            applicationScope.launch {
                populateCategories()
                populateSampleTransaction() // Call new method to add sample transaction
            }
        }

        suspend fun populateCategories() {
            val categoryDao = categoryDaoProvider.get()
            val defaultCategories = listOf(
                Category(name = "Food"),
                Category(name = "Transport"),
                Category(name = "Shopping"),
                Category(name = "Bills"),
                Category(name = "Entertainment"),
                Category(name = "Health"),
                Category(name = "Salary"),
                Category(name = "Freelance"),
                Category(name = "Gifts"),
                Category(name = "Other")
            )
            categoryDao.insertCategories(defaultCategories)
        }

        suspend fun populateSampleTransaction() {
            val categoryDao = categoryDaoProvider.get()
            val transactionDao = transactionDaoProvider.get()

            // Get the "Food" category (assuming it's inserted by populateCategories)
            val foodCategory = categoryDao.getCategoryByName("Food") // Assumes such a method exists in CategoryDao

            foodCategory?.let {
                val sampleTransaction = Transaction(
                    amount = 12.50,
                    date = Date().time, // Changed to Long timestamp
                    categoryId = it.id,
                    description = "Lunch at cafe - Quick lunch", // Combined title and description
                    type = "expense" // Added type
                )
                transactionDao.insertTransaction(sampleTransaction)
            }
        }
    }
}
