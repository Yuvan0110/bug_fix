package com.example.expensetracker.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.constraintlayout.compose.ConstraintLayout
import androidx.constraintlayout.compose.Dimension
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.expensetracker.ui.addexpense.AddExpenseScreen
import com.example.expensetracker.ui.addexpense.AddExpenseViewModel
import com.example.expensetracker.ui.analytics.SpendingPatternsScreen
import com.example.expensetracker.ui.history.TransactionHistoryScreen
import com.example.expensetracker.ui.navigation.AppBottomNavigationBar
import com.example.expensetracker.ui.navigation.Screen
import com.example.expensetracker.ui.navigation.bottomNavItems
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                val navController = rememberNavController()
                MainScreen(navController)
            }
        }
    }
}


@OptIn(ExperimentalAnimationApi::class)
@Composable
fun MainScreen(navController: NavController) {
    val currentScreen by navController.currentBackStackEntryAsState()
    val currentRoute = currentScreen?.destination?.route

    // Root ConstraintLayout
    ConstraintLayout(
        modifier = Modifier.fillMaxSize()
    ) {
        // Create constraints for the entire screen
        val (content, bottomBar) = createRefs()

        // Content Section (Screens based on current route)
        ConstraintLayout(
            modifier = Modifier.constrainAs(content) {
                width = Dimension.fillToConstraints
                height = Dimension.fillToConstraints
                top.linkTo(parent.top)
                bottom.linkTo(parent.bottom)
                start.linkTo(parent.start)
                end.linkTo(parent.end)
            }
        ) {
            // Screens
            AnimatedVisibility(visible = currentRoute == Screen.AddExpense.route) {
                AddExpenseScreen(
                    viewModel = hiltViewModel(),
                    onNavigateBack = { /* Handle back navigation */ },)
            }

            AnimatedVisibility(visible = currentRoute == Screen.TransactionHistory.route) {
                TransactionHistoryScreen()
            }

            AnimatedVisibility(visible = currentRoute == Screen.SpendingPatterns.route) {
                SpendingPatternsScreen()
            }
        }

        // Bottom Navigation Bar Section
        AppBottomNavigationBar(
            navController = navController,
            items = bottomNavItems,
            modifier = Modifier.constrainAs(bottomBar) {
                bottom.linkTo(parent.bottom)
                top.linkTo(parent.top)
                start.linkTo(parent.start)
                end.linkTo(parent.end)
            }
        )
    }
}