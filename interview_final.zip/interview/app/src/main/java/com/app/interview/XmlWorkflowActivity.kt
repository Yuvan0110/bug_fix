package com.app.interview

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.app.interview.adapters.WorkflowAdapter
import com.app.interview.models.WorkflowItem

class XmlWorkflowActivity : AppCompatActivity() {
    
    private lateinit var recyclerView: RecyclerView
    private lateinit var addButton: Button
    private lateinit var workflowAdapter: WorkflowAdapter
    private val workflowList = mutableListOf<WorkflowItem>()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_xml_workflow)
        
        setupViews()
        setupRecyclerView()
        setupClickListeners()
    }
    
    private fun setupViews() {
        recyclerView = findViewById(R.id.recyclerView)
        addButton = findViewById(R.id.add_button)
    }
    
    private fun setupRecyclerView() {
        workflowAdapter = WorkflowAdapter(workflowList) { workflowItem ->
            // Navigate to workflow details
            val intent = Intent(this, XmlWorkflowDetailsActivity::class.java)
            intent.putExtra("workflow_id", workflowItem.id)
            intent.putExtra("workflow_title", workflowItem.title)
            intent.putExtra("workflow_description", workflowItem.description)
            intent.putExtra("workflow_status", workflowItem.status)
            startActivityForResult(intent, WORKFLOW_DETAILS_REQUEST)
        }

        recyclerView.adapter = workflowAdapter
        
        // Add some sample data
        addSampleData()
    }
    
    private fun setupClickListeners() {
        addButton.setOnClickListener {
            val intent = Intent(this, XmlAddWorkflowActivity::class.java)
            startActivityForResult(intent, ADD_WORKFLOW_REQUEST)
        }
    }
    
    private fun addSampleData() {
        workflowList.addAll(listOf(
            WorkflowItem("1", "Project Planning", "Plan and organize project tasks", "In Progress"),
            WorkflowItem("2", "Code Review", "Review team code submissions", "Pending"),
            WorkflowItem("3", "Testing Phase", "Execute comprehensive testing", "Completed"),
            WorkflowItem("4", "Project Planning", "Plan and organize project tasks", "In Progress"),
            WorkflowItem("5", "Code Review", "Review team code submissions", "Pending"),
            WorkflowItem("6", "Testing Phase", "Execute comprehensive testing", "Completed"),
            WorkflowItem("7", "Project Planning", "Plan and organize project tasks", "In Progress"),
            WorkflowItem("8", "Code Review", "Review team code submissions", "Pending"),
            WorkflowItem("9", "Testing Phase", "Execute comprehensive testing", "Completed")
        ))
    }
    
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        when (requestCode) {
            ADD_WORKFLOW_REQUEST -> {
                val title = data?.getStringExtra("title") ?: ""
                val description = data?.getStringExtra("description") ?: ""
                val status = data?.getStringExtra("status") ?: "Pending"
                
                val newWorkflow = WorkflowItem(
                    id = "1",
                    title = title,
                    description = description,
                    status = status
                )
                workflowList.add(newWorkflow)
            }
            WORKFLOW_DETAILS_REQUEST -> {
                val action = data?.getStringExtra("action")
                val workflowId = data?.getStringExtra("workflow_id") ?: ""
                
                when (action) {
                    "update" -> {
                        val title = data?.getStringExtra("title") ?: ""
                        val description = data?.getStringExtra("description") ?: ""
                        val status = data?.getStringExtra("status") ?: ""
                        
                        val index = workflowList.indexOfFirst { it.id == workflowId }
                        if (index >= 0) {
                            workflowList[index] = WorkflowItem(workflowId, title, description, status)
                        }
                    }
                    "delete" -> {
                        val index = workflowList.indexOfFirst { it.id == workflowId }
                        if (index >= 0) {
                            workflowList.removeAt(index)
                        }
                    }
                }
            }
        }
    }
    
    companion object {
        const val ADD_WORKFLOW_REQUEST = 1001
        const val WORKFLOW_DETAILS_REQUEST = 1002
    }
}
