package com.app.interview.models

data class WorkflowItem(
    val id: String,
    val title: String,
    val description: String,
    val status: String
)
