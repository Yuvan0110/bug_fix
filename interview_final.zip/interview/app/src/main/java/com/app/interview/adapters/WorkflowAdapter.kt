package com.app.interview.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.app.interview.R
import com.app.interview.models.WorkflowItem

class WorkflowAdapter(
    private val workflowList: List<WorkflowItem>,
    private val onItemClick: (WorkflowItem) -> Unit
) : RecyclerView.Adapter<WorkflowAdapter.WorkflowViewHolder>() {

    class WorkflowViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val titleTextView: TextView = itemView.findViewById(R.id.titleTextView)
        val descriptionTextView: TextView = itemView.findViewById(R.id.descriptionTextView)
        val statusTextView: TextView = itemView.findViewById(R.id.statusTextView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WorkflowViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_workflow, parent, false)
        return WorkflowViewHolder(view)
    }

    override fun onBindViewHolder(holder: WorkflowViewHolder, position: Int) {
        val workflow = workflowList[position]
        
        holder.titleTextView.text = workflow.title
        holder.descriptionTextView.text = workflow.description
        holder.statusTextView.text = workflow.status
        
        // Set status color
        when (workflow.status) {
            "Completed" -> holder.statusTextView.setTextColor(
                holder.itemView.context.getColor(android.R.color.holo_green_dark)
            )
            "In Progress" -> holder.statusTextView.setTextColor(
                holder.itemView.context.getColor(android.R.color.holo_orange_dark)
            )
            "Pending" -> holder.statusTextView.setTextColor(
                holder.itemView.context.getColor(android.R.color.holo_blue_dark)
            )
        }
        
        holder.itemView.setOnClickListener {
            onItemClick(workflow)
        }
    }

    override fun getItemCount(): Int = workflowList.size
}
