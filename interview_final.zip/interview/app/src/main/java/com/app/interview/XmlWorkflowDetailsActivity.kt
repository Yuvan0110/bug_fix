package com.app.interview

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class XmlWorkflowDetailsActivity : AppCompatActivity() {
    
    private lateinit var titleTextView: TextView
    private lateinit var descriptionTextView: TextView
    private lateinit var statusTextView: TextView
    private lateinit var idTextView: TextView
    private lateinit var editButton: Button
    
    private var workflowId: String = ""
    private var workflowTitle: String = ""
    private var workflowDescription: String = ""
    private var workflowStatus: String = ""
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_workflow_details)
        
        setupViews()
        loadWorkflowData()
        setupClickListeners()
    }
    
    private fun setupViews() {
        titleTextView = findViewById(R.id.titleTextView)
        descriptionTextView = findViewById(R.id.descriptionTextView)
        statusTextView = findViewById(R.id.statusTextView)
        idTextView = findViewById(R.id.idTextView)
        editButton = findViewById(R.id.editButton)
    }
    
    private fun loadWorkflowData() {
        workflowId = intent.getStringExtra("workflow_id") ?: ""
        workflowTitle = intent.getStringExtra("workflow_title") ?: ""
        workflowDescription = intent.getStringExtra("workflow_description") ?: ""
        workflowStatus = intent.getStringExtra("workflow_status") ?: ""
        
        idTextView.text = "ID: $workflowId"
        titleTextView.text = workflowTitle
        descriptionTextView.text = workflowDescription
        statusTextView.text = "Status: $workflowStatus"
        
        // Set status color
        when (workflowStatus) {
            "Completed" -> statusTextView.setTextColor(getColor(android.R.color.holo_green_dark))
            "In Progress" -> statusTextView.setTextColor(getColor(android.R.color.holo_orange_dark))
            "Pending" -> statusTextView.setTextColor(getColor(android.R.color.holo_blue_dark))
        }
    }
    
    private fun setupClickListeners() {
        editButton.setOnClickListener {
            val intent = Intent(this, XmlEditWorkflowActivity::class.java)
            intent.putExtra("workflow_id", workflowId)
            intent.putExtra("workflow_title", workflowTitle)
            intent.putExtra("workflow_description", workflowDescription)
            intent.putExtra("workflow_status", workflowStatus)
            startActivityForResult(intent, EDIT_WORKFLOW_REQUEST)
        }
    }
    
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        
        if (requestCode == EDIT_WORKFLOW_REQUEST && resultCode == Activity.RESULT_OK) {
            val action = data?.getStringExtra("action")
            
            when (action) {
                "update" -> {
                    val title = data?.getStringExtra("title") ?: ""
                    val description = data?.getStringExtra("description") ?: ""
                    val status = data?.getStringExtra("status") ?: ""
                    
                    // Update local data
                    workflowTitle = title
                    workflowDescription = description
                    workflowStatus = status
                    
                    // Pass result back to main activity
                    val resultIntent = Intent()
                    resultIntent.putExtra("workflow_id", workflowId)
                    resultIntent.putExtra("title", title)
                    resultIntent.putExtra("description", description)
                    resultIntent.putExtra("status", status)
                    resultIntent.putExtra("action", "update")
                    setResult(Activity.RESULT_OK, resultIntent)
                }
                "delete" -> {
                    // Pass delete result back to main activity
                    val resultIntent = Intent()
                    resultIntent.putExtra("workflow_id", workflowId)
                    resultIntent.putExtra("action", "delete")
                    setResult(Activity.RESULT_OK, resultIntent)
                    finish()
                }
            }
        }
    }
    
    companion object {
        const val EDIT_WORKFLOW_REQUEST = 1002
    }
}
