package com.app.interview

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.app.interview.models.WorkflowItem
import com.app.interview.ui.theme.InterviewTheme

class ComposeWorkflowActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            InterviewTheme {
                ComposeWorkflowScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ComposeWorkflowScreen() {
    val context = LocalContext.current
    var workflowList = getSampleWorkflows()
    
    // Activity result launcher for adding new workflow
    val addWorkflowLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val data = result.data
            val title = data?.getStringExtra("title") ?: ""
            val description = data?.getStringExtra("description") ?: ""
            val status = data?.getStringExtra("status") ?: "Pending"
            
            val newWorkflow = WorkflowItem(
                id = "1",
                title = title,
                description = description,
                status = status
            )
            
            workflowList = workflowList + newWorkflow
        }
    }
    
    // Activity result launcher for workflow details
    val workflowDetailsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val data = result.data
            val action = data?.getStringExtra("action")
            val workflowId = data?.getStringExtra("workflow_id") ?: ""
            
            when (action) {
                "update" -> {
                    val title = data?.getStringExtra("title") ?: ""
                    val description = data?.getStringExtra("description") ?: ""
                    val status = data?.getStringExtra("status") ?: ""
                    
                    workflowList = workflowList.map { workflow ->
                        if (workflow.id == workflowId) {
                            WorkflowItem(workflowId, title, description, status)
                        } else {
                            workflow
                        }
                    }
                }
                "delete" -> {
                    workflowList = workflowList.filter { it.id != workflowId }
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        "Workflow Management (Compose)",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    val intent = Intent(context, ComposeAddWorkflowActivity::class.java)
                    addWorkflowLauncher.launch(intent)
                },
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Workflow")
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(workflowList) { workflow ->
                WorkflowCard(
                    workflow = workflow,
                    onClick = {
                        val intent = Intent(context, ComposeWorkflowDetailsActivity::class.java)
                        intent.putExtra("workflow_id", workflow.id)
                        intent.putExtra("workflow_title", workflow.title)
                        intent.putExtra("workflow_description", workflow.description)
                        intent.putExtra("workflow_status", workflow.status)
                        context.startActivity(intent)
                    }
                )
            }
        }
    }
}

@Composable
fun WorkflowCard(
    workflow: WorkflowItem,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        onClick = onClick
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = workflow.title,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = workflow.description,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ID: ${workflow.id}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.outline
                )
                
                WorkflowStatusChip(status = workflow.status)
            }
        }
    }
}

private fun getSampleWorkflows(): List<WorkflowItem> = listOf(
    WorkflowItem("1", "Project Planning", "Plan and organize project tasks", "In Progress"),
    WorkflowItem("2", "Code Review", "Review team code submissions", "Pending"),
    WorkflowItem("3", "Testing Phase", "Execute comprehensive testing", "Completed")
)
