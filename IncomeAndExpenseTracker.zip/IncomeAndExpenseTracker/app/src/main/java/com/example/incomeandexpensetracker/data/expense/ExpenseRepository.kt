package com.example.incomeandexpensetracker.data.expense

import kotlinx.coroutines.flow.Flow

interface ExpenseRepository {

    suspend fun insertExpense(expense: Expense)

    fun getExpensesByUser(userId: Int): Flow<List<Expense>>

    fun getTotalExpense(userId: Int): Flow<Int>

    fun getExpensesByCategory(userId: Int, category: String): Flow<List<Expense>>

}