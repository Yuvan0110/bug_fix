package com.example.incomeandexpensetracker.data.income

import kotlinx.coroutines.flow.Flow

class IncomeRepositoryImpl(
    private val incomeDao: IncomeDao
): IncomeRepository {

    override suspend fun insertIncomeTo(income: Income) {
        incomeDao.insertIncome(income)
    }

    override fun getIncomesByUserTo(userId: Int): Flow<List<Income>> {
        return incomeDao.getIncomesByUser(userId)
    }

    override fun getTotalIncomeTo(userId: Int): Flow<Int> {
        return incomeDao.getTotalIncome(userId)
    }

}