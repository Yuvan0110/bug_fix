package com.example.incomeandexpensetracker.data.user

import kotlinx.coroutines.flow.Flow

interface UserRepository {

    suspend fun addUserTo(user: User)

    suspend fun updateUserTo(user: User)

    suspend fun deleteUserTo(user: User)

    fun getUserByIdTo(id: Int): Flow<User>

    fun getAllUsersTo(): Flow<List<User>>

}