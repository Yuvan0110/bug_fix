package com.example.incomeandexpensetracker.data.expense

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey
import com.example.incomeandexpensetracker.data.user.User

@Entity(
    tableName = "expense",
    foreignKeys = [
        ForeignKey(
            entity = User::class,
            parentColumns = ["userId"],
            childColumns = ["userId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class Expense(
    val amount: Int,
    val category: String,
    val expenseTimestamp: String,
    val userId: Int,
    @PrimaryKey(autoGenerate = true)
    val expenseId: Int = 0
)

