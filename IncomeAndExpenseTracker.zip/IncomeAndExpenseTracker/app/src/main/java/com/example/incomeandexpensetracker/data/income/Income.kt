package com.example.incomeandexpensetracker.data.income

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey
import com.example.incomeandexpensetracker.data.user.User

@Entity(
    tableName = "income",
    foreignKeys = [
        ForeignKey(
            entity = User::class,
            parentColumns = ["userId"],
            childColumns = ["userId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class Income(
    val amount: Int,
    val incomeTimestamp: String,
    val userId: Int,
    @PrimaryKey(autoGenerate = true)
    val incomeId: Int = 0
)