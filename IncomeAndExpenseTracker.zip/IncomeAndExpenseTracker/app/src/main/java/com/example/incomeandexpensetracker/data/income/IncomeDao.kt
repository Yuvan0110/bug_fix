package com.example.incomeandexpensetracker.data.income

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface IncomeDao {

    // add income
    @Insert
    suspend fun insertIncome(income: Income)

    // get income by user_id
    @Query("SELECT * FROM income WHERE userId = :userId ORDER BY incomeTimestamp DESC")
    fun getIncomesByUser(userId: Int): Flow<List<Income>>

    // get total income by user_id
    @Query("SELECT SUM(amount) FROM income WHERE userId = :userId")
    fun getTotalIncome(userId: Int): Flow<Int>

}
