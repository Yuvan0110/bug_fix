package com.example.incomeandexpensetracker.data.income

import kotlinx.coroutines.flow.Flow

interface IncomeRepository {

    suspend fun insertIncomeTo(income: Income)

    fun getIncomesByUserTo(userId: Int): Flow<List<Income>>

    fun getTotalIncomeTo(userId: Int): Flow<Int>

}