package com.example.incomeandexpensetracker.data.user

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {

    // add new user
    @Insert
    suspend fun addUser(user: User)

    // update user info
    @Update
    suspend fun updateUser(user: User)

    // delete user
    @Delete
    suspend fun deleteUser(user: User)

    // get user info by id
    @Query("SELECT * FROM user WHERE userId = :id")
    fun getUserById(id: Int): Flow<User>

    // list all users
    @Query("SELECT * FROM user")
    fun getAllUsers(): Flow<List<User>>
}

