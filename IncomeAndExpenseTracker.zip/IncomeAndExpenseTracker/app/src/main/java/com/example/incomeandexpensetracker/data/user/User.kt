package com.example.incomeandexpensetracker.data.user

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user")
data class User(
    val username: String,
    val availAmount: Int = 0,
    @PrimaryKey(autoGenerate = true)
    val userId: Int = 0
)
