package com.example.incomeandexpensetracker.data.user

import kotlinx.coroutines.flow.Flow

class UserRepositoryImpl(
    private val userDao: UserDao
): UserRepository {

    override suspend fun addUserTo(user: User) {
        userDao.addUser(user)
    }

    override suspend fun updateUserTo(user: User) {
        userDao.updateUser(user)
    }

    override suspend fun deleteUserTo(user: User) {
        userDao.deleteUser(user)
    }

    override  fun getUserByIdTo(id: Int): Flow<User> {
        return userDao.getUserById(id)
    }

    override fun getAllUsersTo(): Flow<List<User>> {
        return userDao.getAllUsers()
    }

}