package com.example.incomeandexpensetracker.data.expense

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ExpenseDao {

    // add expense
    @Insert
    suspend fun insertExpense(expense: Expense)

    // get expenses by user_id
    @Query("SELECT * FROM expense WHERE userId = :userId ORDER BY expenseTimestamp DESC")
    fun getExpensesByUser(userId: Int): Flow<List<Expense>>

    // get total expense by user_id
    @Query("SELECT SUM(amount) FROM expense WHERE userId = :userId")
    fun getTotalExpense(userId: Int): Flow<Int>

    // get expenses by category by user_id
    @Query("SELECT * FROM expense WHERE userId = :userId AND category = :category ORDER BY expenseTimestamp DESC")
    fun getExpensesByCategory(userId: Int, category: String): Flow<List<Expense>>

}