package com.example.incomeandexpensetracker.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.incomeandexpensetracker.data.expense.Expense
import com.example.incomeandexpensetracker.data.expense.ExpenseDao
import com.example.incomeandexpensetracker.data.income.Income
import com.example.incomeandexpensetracker.data.income.IncomeDao
import com.example.incomeandexpensetracker.data.user.User
import com.example.incomeandexpensetracker.data.user.UserDao

@Database(
    entities = [User::class, Income::class, Expense::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun incomeDao(): IncomeDao
    abstract fun expenseDao(): ExpenseDao


    companion object {
        @Volatile
        private var Instance: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return Instance ?: synchronized(this) {
                Room.databaseBuilder(
                    context,
                    AppDatabase::class.java,
                    "income_expense_db"
                )
                    .build()
                    .also { Instance = it }
            }
        }
    }
}