package com.example.incomeandexpensetracker.data.expense

import kotlinx.coroutines.flow.Flow

class ExpenseRepositoryImpl(
    private val expenseDao: ExpenseDao
): ExpenseRepository {

    override suspend fun insertExpense(expense: Expense) {
        expenseDao.insertExpense(expense)
    }

    override fun getExpensesByUser(userId: Int): Flow<List<Expense>> {
        return expenseDao.getExpensesByUser(userId)
    }

    override fun getTotalExpense(userId: Int): Flow<Int> {
        return expenseDao.getTotalExpense(userId)
    }

    override fun getExpensesByCategory(
        userId: Int,
        category: String
    ): Flow<List<Expense>> {
        return expenseDao.getExpensesByCategory(userId, category)
    }

}